<div align="center">

# 🌙 Insomnia

**Insomnia** is a **Discord nuke bot**.  
It is designed to be a **fast and nuker** and demonstrate new ways of nuking servers by bypassing some limits.  

</div>
<p align="center">
  <img src="https://i.ibb.co/Xf6xHJqk/insomnia-dark.png" width="250" height="250">
</p>

## ✨ Features

- ⚡ Nukes fast and efficient
- 🤖 MANY commands
- ⚙️ Ratelimit bypass 
- ⭐ Premium system


---

## 🚀 Usage

```bash
# Install dependencies
just use ur brain

# Run
python nuke.py
````

---

<div align="center">

### ⚖️ Ethical & Legal Notice 
</div>

🔸 It does **not encourage or support malicious activity**.  

🔸 Always use responsibly in **controlled environments** such as penetration testing labs or awareness training.   